from django.db import models

# Create your models here.

class Destination :
    id : int
    heading : str
    img : str
    